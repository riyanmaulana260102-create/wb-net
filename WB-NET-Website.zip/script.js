const toggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav-links');
toggle?.addEventListener('click', () => {
  const open = nav.style.display === 'flex';
  nav.style.display = open ? '' : 'flex';
  if (!open) {
    nav.style.position = 'absolute';
    nav.style.top = '72px';
    nav.style.left = '0';
    nav.style.right = '0';
    nav.style.background = '#fff';
    nav.style.flexDirection = 'column';
    nav.style.padding = '12px 20px 20px';
    nav.style.boxShadow = '0 8px 20px #0002';
    nav.querySelectorAll('a').forEach(a => a.style.height = '42px');
  }
});
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', () => {
    if (window.innerWidth <= 900) nav.style.display = '';
  });
});
