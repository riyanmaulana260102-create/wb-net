WB-NET Website

Buka index.html di browser.
Website dibuat sebagai versi responsif dari desain referensi yang diberikan.
Nomor WhatsApp dan paket sudah dibuat sebagai tombol yang dapat diklik.
